'use strict';

var gulp =require('gulp');
var browserify = require('gulp-browserify');
var minifyCSS =require('gulp-minify-css');
var uglify =require('gulp-uglify');
var connect = require('gulp-connect');
var rename = require("gulp-rename");


//使用类似于  require() 的方式来组织浏览器端的 Javascript 代码
gulp.task('browserify',function() {
  return  gulp.src(src.browserify[0])
    .pipe(browserify({
      debug: false   //debug: true 是告知Browserify在运行同时生成内联sourcemap用于调试。
    }))
    .on('error', function(err) {
      console.error(err.stack);
    })
    .pipe(gulp.dest(build.browserify[0]));
})
// css压缩
gulp.task('css', function () {
    gulp.src('Css/style.css')
      .pipe(minifyCSS())
      .pipe(gulp.dest('dist/css/'))
})
//js 压缩 gulp script
gulp.task('script', function() {
    gulp.src('Scripts/Xport.js')
      .pipe(uglify())
      .pipe(rename({ suffix: '.min'}))
      .pipe(gulp.dest('dist/js/'));
})


//将js加上10位md5,并修改html中的引用路径，该动作依赖build-js
gulp.task('md5-js', ['script'], function (done) {
    gulp.src('dist/js/*.js')
        .pipe(md5(8, 'html/*.html'))
        .pipe(gulp.dest('dist/js'))
        .on('end', done);
});

//将css加上10位md5，并修改html中的引用路径，该动作依赖sprite
gulp.task('md5-css', ['css'], function (done) {
    gulp.src('dist/css/*.css')
        .pipe(md5(8, ['html/*.html','./*.html']))
        .pipe(gulp.dest('dist/css'))
        .on('end', done);
});



gulp.task('webserver', function() {
    connect.server({
      livereload: true
    });
});


// 正式上线任务
//gulp.task('md5', ['md5-js','md5-css']);

//开发
gulp.task('watch', ['script','css'], function() {
  var watcher = gulp.watch('js/*.js', ['browserify']);
  watcher.on('change', function(event) {
    console.log(new Array(80).join('='));
    console.log(event.path + ' was changed.');
    console.log(new Array(80).join('='));
  });
});
gulp.task('default', ['css']);
gulp.task('devserver',  ['webserver']);