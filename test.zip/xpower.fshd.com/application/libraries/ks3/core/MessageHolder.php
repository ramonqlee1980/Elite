<?php
class MessageHolder{
	public $msg;
}
?>