window.onload= function(){
  var scrolltop=document.documentElement.scrollTop||document.body.scrollTop;
  if(scrolltop==0){
      $("body").removeClass('is-scroll');
    }else{
       $("body").addClass('is-scroll');
    }
  $('body').addClass('is-loaded');
  $('body').scrollspy({ target: '.navbar-collapse' })
  window.onscroll = function(e){
    var e =e || window.event;
     scrolltop=document.documentElement.scrollTop||document.body.scrollTop;
    if(scrolltop==0){
      $("body").removeClass('is-scroll');
    }else{
      $("body").addClass('is-scroll');
    }
  }
}
var appMaster = {
  headerJs: function(){
    function header() {
      $(window).height();
      $(window).width() > 767;
    }

    var header_fix = $(".header");
    var inner_header = $(".inner-inro");
    $(window).scroll(function() {
      $(this).scrollTop() > 1 ? (header_fix.addClass("sticky"), inner_header.css("z-index", "-1")) : (header_fix.removeClass("sticky"), inner_header.css("z-index", "auto"));
    }), header(), $(window).resize(function() {
      header();
    });
  },
  /*----------------------------------------------
   ----------- video  --------------------
   -------------------------------------------------*/
    videoJs: function(){
      var videoBg = $(".bg-video");
      if(videoBg.length){
      videoBg.mediaelementplayer({
        loop: !0,
        enableKeyboard: !1,
        iPadUseNativeControls: !1,
        pauseOtherPlayers: !1,
        iPhoneUseNativeControls: !1,
        AndroidUseNativeControls: !1,
        enableAutosize: !0,
        alwaysShowControls: !1
      });
    }
     $(window).height(function() {
      function e() {
          var e = $(window).innerHeight();
          $(".slider-hero, .full-screen-intro").css("height", e);
      }
      e(), $(window).resize(function() {
          e();
      });
    });
  },
};
(function() {

  //newslist();
  var demo = document.getElementById("newslist");
  var demo1 = document.getElementById("newslist1");
  var demo2 = document.getElementById("newslist2");
  if(demo &&demo1 && demo2){
    demo2.innerHTML= demo1.innerHTML;
     function Marquee(){
    if(demo.scrollLeft-demo2.offsetWidth>=0){
     demo.scrollLeft-=demo1.offsetWidth;
    }
    else{
     demo.scrollLeft++;
    }
  }
  var myvar=setInterval(Marquee,90);
  demo.onmouseout=function (){ myvar=setInterval(Marquee,90); }
  demo.onmouseover=function(){ clearInterval(myvar); }
  }
  
 

  var $page3 = $('#Project-plan'),
    $timelineLis = $('.timeline li'),
    timelineLen = $timelineLis.length,
    $dot = $page3.find('span.dot'),
    page3Timer = 0,
    page3AutoRun = 0,
    page3pause = 0,
    page3Current = 0;

  function activeDotAndTimeline(idx) {
    var $target = $timelineLis.eq(idx);
    $target.parents('.timeline').find('li').removeClass("current");
    $target.addClass("current");
  }
  function move() {
    page3Timer = setInterval(function() {
    page3Current++;
    if(page3Current>7) {
      page3Current=0;
    }
    activeDotAndTimeline(page3Current);
  },3000)
  }
  $timelineLis.mouseover(function() {
      var self = this;
      clearTimeout(page3Timer);
      page3Timer = setTimeout(function() {
          page3Current = $(self).attr('data-index')
          activeDotAndTimeline(page3Current);
      }, 500);
      page3pause = 1;
  }).mouseout(function() {
    move();
    page3pause = 0;
  });

  move();

}());

$(document).ready(function() {
  var config = {
      vx: 4,  //小球x轴速度,正为右，负为左
      vy: 4,  //小球y轴速度
      height: 3,  //小球高宽，其实为正方形，所以不宜太大
      width: 3,
      count: 200,   //点个数
      color: "255, 255, 255",   //点颜色
      stroke: "255,255,255",    //线条颜色
      dist: 5000,   //点吸附距离
      e_dist: 10000,  //鼠标吸附加速距离
      max_conn: 10  //点到点最大连接数
  }
  if(!/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {
   CanvasParticle(config);
  }
  var moreEl = $('.more');

  moreEl.on('click',function(){
    if($(this).hasClass('on')) {
      $(this).removeClass('on').text('MORE');
    }else {
      $(this).addClass('on').text('Pack up');
    }
    var peopleCur = $(this).parent('li');
    peopleCur.siblings().find('.more').text('MORE').end().find('.detail').slideUp();
    peopleCur.find('.detail').slideToggle();
  });

  
}); 

